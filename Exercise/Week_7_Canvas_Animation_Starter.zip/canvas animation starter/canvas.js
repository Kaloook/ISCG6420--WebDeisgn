const canvas = document.getElementById("myCanvas");
const ctx = canvas.getContext("2d");

function Logo() {
    
}

let logos = [];

canvas.addEventListener("click", () => {logos.push(new Logo());});

logos.push(new Logo());

run();


function run() {

}

function update() {
    
}

function draw() {

}

function random(min, max) {
    return Math.floor((Math.random() * (max - min + 1)) + min);
}

function checkWallCollision(object) {

}

