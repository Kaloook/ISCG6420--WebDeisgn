$('document').ready(function () {
    // exercise 1: jQuery Selectors



    // exercise 2: Selector filtering



    // exercise 3: Click events



    // exercise 4: Hover events


    // exercise 5: Focus events
    // Week 9


    // exercise 6: Show and Hide effects
    // Week 9


    // exercise 7: Fade effects
    // Week 9


    // exercise 8: Slide

    

    // exercise 9: Animations



    // exercise 10: Animation chaining


    
    // exercise 11: Element creation

});