# jquery-exercise-starter
Starter project files for ISCG6420 2024 S1 Week 8 jQuery exercises.
